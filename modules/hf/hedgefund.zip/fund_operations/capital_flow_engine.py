"""HF-5: capital_flow_engine.py"""
